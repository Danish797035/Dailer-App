import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:app/main.dart';

void main() {
  testWidgets('Phone Dialer basic UI test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    // Verify that the title 'Phone' is present
    expect(find.text('Phone'), findsOneWidget);

    // Verify that the call button is present (FloatingActionButton with phone icon)
    expect(find.byIcon(Icons.phone), findsWidgets);

    // Verify that numbers 0-9 are present on the dial pad
    for (int i = 0; i <= 9; i++) {
      expect(find.text('$i'), findsWidgets);
    }
  });
}
