import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:intl/intl.dart';

class CallHistoryItem {
  final String number;
  final DateTime time;

  CallHistoryItem({required this.number, required this.time});
}

class PhoneDialerScreen extends StatefulWidget {
  const PhoneDialerScreen({super.key});

  @override
  State<PhoneDialerScreen> createState() => _PhoneDialerScreenState();
}

class _PhoneDialerScreenState extends State<PhoneDialerScreen> {
  String _typedNumber = '';
  List<Contact> _contacts = [];
  List<CallHistoryItem> _callHistory = [];
  bool _showContacts = false;

  @override
  void initState() {
    super.initState();
    _fetchContacts();
  }

  Future<void> _fetchContacts() async {
    if (await FlutterContacts.requestPermission()) {
      final contacts = await FlutterContacts.getContacts(withProperties: true);
      setState(() => _contacts = contacts);
    }
  }

  void _onDigitPressed(String digit) {
    setState(() {
      _typedNumber += digit;
    });
  }

  void _onBackspacePressed() {
    if (_typedNumber.isNotEmpty) {
      setState(() {
        _typedNumber = _typedNumber.substring(0, _typedNumber.length - 1);
      });
    }
  }

  Future<void> _onCallPressed() async {
    if (_typedNumber.isEmpty) return;
    
    setState(() {
      _callHistory.insert(0, CallHistoryItem(
        number: _typedNumber,
        time: DateTime.now(),
      ));
    });

    final Uri launchUri = Uri(
      scheme: 'tel',
      path: _typedNumber,
    );
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not launch dialer')),
        );
      }
    }
  }

  void _onEndCallPressed() {
    // We cannot truly end a call started by url_launcher as it launches the system dialer.
    // However, we simulate "end call" functionality by clearing the typed number.
    setState(() {
      _typedNumber = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Phone'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Call History or Contacts List (takes remaining space)
          Expanded(
            child: _showContacts ? _buildContactsList() : _buildCallHistory(),
          ),
          
          // Display Screen (fixed size)
          Container(
            height: 100,
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            alignment: Alignment.bottomCenter,
            child: SingleChildScrollView(
              reverse: true,
              scrollDirection: Axis.horizontal,
              child: Text(
                _typedNumber,
                style: const TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w400,
                  letterSpacing: 2,
                ),
                maxLines: 1,
              ),
            ),
          ),
          
          // Number Pad (fixed size at bottom)
          Container(
            padding: const EdgeInsets.only(bottom: 32),
            child: Column(
              children: [
                _buildRow(['1', '2', '3']),
                _buildRow(['4', '5', '6']),
                _buildRow(['7', '8', '9']),
                _buildRow(['*', '0', '#']),
                
                // Action Buttons Row
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Contacts / History Toggle
                      IconButton(
                        onPressed: () {
                          setState(() {
                            _showContacts = !_showContacts;
                          });
                        },
                        icon: Icon(
                          _showContacts ? Icons.history : Icons.contacts, 
                          size: 32
                        ),
                        color: Colors.grey,
                      ),
                      
                      // Call / End Call Action Buttons
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FloatingActionButton(
                            onPressed: _onCallPressed,
                            backgroundColor: Colors.green,
                            child: const Icon(Icons.phone, size: 32, color: Colors.white),
                            elevation: 0,
                            shape: const CircleBorder(),
                          ),
                          if (_typedNumber.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: FloatingActionButton(
                                onPressed: _onEndCallPressed,
                                backgroundColor: Colors.red,
                                child: const Icon(Icons.call_end, size: 32, color: Colors.white),
                                elevation: 0,
                                shape: const CircleBorder(),
                              ),
                            ),
                        ],
                      ),
                      
                      // Backspace Button
                      IconButton(
                        onPressed: _onBackspacePressed,
                        icon: const Icon(Icons.backspace, size: 32),
                        color: _typedNumber.isNotEmpty ? Colors.grey : Colors.transparent,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactsList() {
    if (_contacts.isEmpty) {
      return const Center(child: Text('No contacts found'));
    }
    return ListView.builder(
      itemCount: _contacts.length,
      itemBuilder: (context, index) {
        final contact = _contacts[index];
        final String phoneNumber = contact.phones.isNotEmpty 
            ? contact.phones.first.number 
            : '';
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.green.withOpacity(0.2),
            child: Text(contact.displayName.isNotEmpty ? contact.displayName[0].toUpperCase() : '?'),
          ),
          title: Text(contact.displayName),
          subtitle: Text(phoneNumber),
          onTap: () {
            if (phoneNumber.isNotEmpty) {
              setState(() {
                // remove spaces and dashes for dialing
                _typedNumber = phoneNumber.replaceAll(RegExp(r'[\s\-]'), '');
              });
            }
          },
        );
      },
    );
  }

  Widget _buildCallHistory() {
    if (_callHistory.isEmpty) {
      return const Center(child: Text('No recent calls', style: TextStyle(color: Colors.grey)));
    }
    return ListView.builder(
      itemCount: _callHistory.length,
      itemBuilder: (context, index) {
        final item = _callHistory[index];
        final timeString = DateFormat('MMM d, h:mm a').format(item.time);
        return ListTile(
          leading: const Icon(Icons.call_made, color: Colors.green),
          title: Text(item.number, style: const TextStyle(fontSize: 18)),
          subtitle: Text(timeString),
          trailing: IconButton(
            icon: const Icon(Icons.phone),
            onPressed: () {
              setState(() {
                _typedNumber = item.number;
              });
              _onCallPressed();
            },
          ),
          onTap: () {
            setState(() {
              _typedNumber = item.number;
            });
          },
        );
      },
    );
  }

  Widget _buildRow(List<String> digits) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: digits.map((digit) {
          return DialButton(
            title: digit,
            subtitle: _getSubtitle(digit),
            onPressed: () => _onDigitPressed(digit),
          );
        }).toList(),
      ),
    );
  }

  String _getSubtitle(String digit) {
    switch (digit) {
      case '1': return ' ';
      case '2': return 'ABC';
      case '3': return 'DEF';
      case '4': return 'GHI';
      case '5': return 'JKL';
      case '6': return 'MNO';
      case '7': return 'PQRS';
      case '8': return 'TUV';
      case '9': return 'WXYZ';
      case '0': return '+';
      default: return ' ';
    }
  }
}

class DialButton extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onPressed;

  const DialButton({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(40),
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w400,
              ),
            ),
            if (subtitle.trim().isNotEmpty)
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
